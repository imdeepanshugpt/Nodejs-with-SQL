import React, { useState, useEffect } from 'react';
import userAPI from './apis/user';
import UserDetails from '../src/components/usercard';

const App = () => {
  const [userData, setUserData] = useState([]);
  const [error, setError] = useState(false);
  
  useEffect(() => {
    userAPI.get('/users').then(res => {
      setUserData(res.data);
      console.log(userData);
    }).catch(err => {
      setError(true);
      console.log('error', error);
    });
  }, []);

  function renderUserCards() {
    return userData.map((user) => {
      return <UserDetails style={{ padding: '10px' }} user={user} key={user.id} />;
    })
  }

  return (
      <div className="App">
        <header className="App-header">
          <h1>User Details</h1>
        </header>
        <div style={{ display: 'flex' }}>
          {renderUserCards()}
        </div>
      </div>
  );
}

export default App;
