import React, { useState } from 'react';
import maleAvatar from '../assests/boy.png';
import womenAvatar from '../assests/girl.png';
import userAPI from '../apis/user';

const UserCard = ({ user }) => {
    const [friends, setFriends] = useState(undefined);

    const fetchFriends = (id) => {
        userAPI.get('/users/friends?id=' + id).then((res) => {
            setFriends(res.data);
        });
    }

    const fetchFOFriends = (id) => {
        userAPI.get('/users/fofriends?id=' + id).then((res) => {
            setFriends(res.data);
        });
    }

    const loadFriends = (friends, flag) => {
        if (friends && (friends.length > 0) && friends !== 'No Data') {
            return friends.map((friend) => {
                return (
                    <ul>
                        <li>
                            {friend.lastname} {friend.firstname}
                        </li>
                    </ul>
                );
            })
        } else if (flag) {
            return (
                <p>No friends</p>
            )
        }
    }

    return (
        <div style={{ border: 'black 1px solid', padding: '5px', width: '13%', margin: '10px' }}>
            {
                user.avatar === 'male' ?
                    <img src={maleAvatar} alt="male" height="42" width="42"></img>
                    : <img src={womenAvatar} alt="women" height="42" width="42"></img>
            }
            <h3>{user.lastname} {user.firstname}</h3>
            <button type="submit"
                style={{ padding: '10px', background: 'grey' }}
                onClick={() => { fetchFriends(user.id, true) }}
            >Friends</button>

            <button type="submit"
                style={{ padding: '10px', background: 'grey' }}
                onClick={() => { fetchFOFriends(user.id, true) }}
            >Friends of Friends</button>
            <div>
                {loadFriends(friends)}
            </div>
        </div>
    )
}

export default UserCard;