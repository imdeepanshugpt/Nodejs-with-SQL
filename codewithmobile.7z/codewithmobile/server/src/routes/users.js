const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const userService = require('../services/userService');

router.use(bodyParser.json());

router.get('/', userService.getUsersList)
router.get('/friends', userService.getUserFriends);
router.get('/fofriends', userService.getUsersFOF);

module.exports = router;