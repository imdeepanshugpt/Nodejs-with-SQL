const connection = require('../../db');

function getUsersList(req, res) {
    return new Promise((resolve, reject) => {
        connection.query("SELECT * FROM userdetails", function (err, result) {
            if (err) throw reject(err);
            res.send(result);
            resolve(result);
        });
    });
}
function getUserFriends(req, res) {
    const id = req.query.id;
    return new Promise((resolve, reject) => {
        let friends = [];
        connection.query("SELECT * FROM userfriendsmapper where userID=" + id, function (err, result) {
            if (err) throw reject(err);
            if (result && result.length === 0) {
                res.send('No Data');
            } else {
                for (let i = 0; i < result.length; i++) {
                    const id = result[i].friendID;
                    connection.query("SELECT * FROM userdetails where id=" + id, function (err, user) {
                        if (err) throw reject(err);
                        friends.push(user[0]);
                        if (i === result.length - 1) {
                            res.send(friends);
                            resolve(friends);
                        }
                    });
                }
            }
        });
    });
}
function getUsersFOF(req, res) {
    const id = req.query.id;
    return new Promise((resolve, reject) => {
        let friendIDS = [];
        let query = '';
        let FOF = [];
        connection.query("SELECT * FROM userfriendsmapper where userID=" + id, function (err, result) {
            if (err) throw reject(err);
            if (result && result.length === 0) {
                res.send('No Data');
            } else {
                for (let i = 0; i < result.length; i++) {
                    friendIDS.push(result[i].friendID);
                    if (i === 0) {
                        query = 'userID=' + result[i].friendID;
                    } else {
                        query = query + ' or userID=' + result[i].friendID;
                    }
                }
                connection.query("SELECT * FROM userfriendsmapper where " + query, function (err, users) {
                    for (let i = 0; i < users.length; i++) {
                        FOF.push(users[i].friendID);
                    }
                    const uniqueFOF = FOF.filter((fid, index) => {
                        return ((FOF.indexOf(fid) === index) && (fid !== Number(id)));
                    });
                    FOF = [];
                    for (let i = 0; i < uniqueFOF.length; i++) {
                        const id = uniqueFOF[i];
                        connection.query("SELECT * FROM userdetails where id=" + id, function (err, user) {
                            if (err) throw reject(err);
                            FOF.push(user[0]);
                            if (i === uniqueFOF.length - 1) {
                                res.send(FOF);
                                resolve(FOF);
                            }
                        });
                    }
                });
            }
        });
    });
}
module.exports = {
    getUsersList,
    getUserFriends,
    getUsersFOF
}